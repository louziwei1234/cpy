// pages/orders/orders.js
const db = wx.cloud.database()
const carts_col=db.collection('carts')

Page({

  data:{
    cartGoods:[]
  },

  onLoad(){
    this.loadCartData()
  },

  async loadCartData(){

    let res = await carts_col.get() 
    this.setData({
     cartGoods : res.data
    })
 }
})