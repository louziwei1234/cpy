// pages/detail/detail.js
const db = wx.cloud.database()

const goods_col = db.collection('commodity')
const carts_col=db.collection('carts')

import {
  ml_showLoading,
  ml_hideLoading,
  ml_showToast,
  ml_showToastSuccess
} from '../../utils/asyncWX.js'

Page({
  data :{
    detail : {}
  },
  onLoad(options){

    let { id } = options

    this.loadDetailData(id)
  },
  // 加载详情数据
  async loadDetailData(id){
    // count +1
     await goods_col.doc(id).update({
      data : {
        count : db.command.inc(1)
      }
    })

    // 获取详情数据
    let res = await goods_col.doc(id).get()
    // console.log('商品信息',res)
    this.setData({
      detail : res.data
    })

    // console.log('商品详情轮播图',detail)

  },
    // 加入到购物车
  
  async collect(e){
    // let id = e.currentTarget.dataset.id
    // let res = await carts_col.doc(id).get()
    // res.data.forEach(v => {
    //   isCollect=!isCollect
    // })
    // let newCollect= this.data.detail
    // let goods = newCollect.find(v => v._id == id)
    // goods.isCollect=!isCollect
    // this.setData({
    //   collect: newCollect
    // })


  }
  
})