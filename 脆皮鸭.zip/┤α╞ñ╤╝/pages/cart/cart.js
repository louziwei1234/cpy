// pages/cart/cart.js
const db = wx.cloud.database({
  env:'cpy-y4r9x'
})
const carts_col = db.collection('carts')
import { ml_showToastSuccess, ml_payment } from '../../utils/asyncWX.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    carts :[],  // 购物车数据
    totalCount :0,
    totalPrice :0
  },
  onLoad(){

    this.loadCartsData()
  },
  // 加载购物车数据
 async loadCartsData(){

    let res = await carts_col.get()
    console.log('购物车数据',res)
    this.setData({
        carts : res.data
    })

    // 统计总价格和总数量
   this.setCart(res.data)
  },
   // 统计总价格和总数量
  setCart(carts){

    let totalCount = 0
    let totalPrice = 0

    carts.forEach(v => {
      totalCount += v.num
      totalPrice += v.num * v.price
    })


    this.setData({
      totalCount,
      totalPrice
    })

  },
   // 点击 + 
   async addCount(e){

    //1. 获取 id 
    let id = e.currentTarget.dataset.id

    //2. 修改num -1 
    let res = await carts_col.doc(id).update({
      data : {
        num : db.command.inc(1)
      }
    })
    console.log('+1',res)
    // 3.1 +1 成功后 再次重新刷新
    // this.loadCartsData()
    // 3.2 +1 成功后 修改当前data里面的carts数据
    let newCarts = this.data.carts
    let goods = newCarts.find(v => v._id == id)
    goods.num += 1
    this.setData({
      carts: newCarts
    })

    //4. 提示 累加成功
    // wx.showToast({
    //   title: '累加成功'
    // })

    //5. 再次统计
    this.setCart(newCarts)
  },

  async decCount(e){

    //1. 获取 id 
    let id = e.currentTarget.dataset.id

    //2. 修改num +1 
    let res = await carts_col.doc(id).update({
      data : {
        num : db.command.inc(1)
      }
    })
    // console.log('+1',res)
    // 3.1 +1 成功后 再次重新刷新
    // this.loadCartsData()
    // 3.2 +1 成功后 修改当前data里面的carts数据
    let newCarts = this.data.carts
    let goods = newCarts.find(v => v._id == id)
    goods.num -= 1
    this.setData({
      carts: newCarts
    })

    //4. 提示 累加成功
    // wx.showToast({
    //   title: '累加成功'
    // })

    //5. 再次统计
    this.setCart(newCarts)
  },

  // 点击 当前页面对应的tab
  onTabItemTap(){
    
    wx.setTabBarBadge({
      index: 1,
      text: '',
    })
  },
  // 开始支付
  async startpay(){

    
    
   await ml_showToastSuccess('发起订单成功')
   
   
   

   // 跳转到订单页面
   wx.navigateTo({
     url: '/pages/orders/orders',
   })

  }
 
  
})